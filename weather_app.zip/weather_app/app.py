from flask import Flask, render_template, request, jsonify
import requests
from datetime import datetime

app = Flask(__name__)
API_KEY = '23f4107c2b2d73401af2376410f76c60'  # Replace with your actual API key

def get_weather_by_city(city):
    url = f'https://api.openweathermap.org/data/2.5/weather?q={city}&appid={API_KEY}&units=metric'
    return requests.get(url).json()

def get_weather_by_coordinates(lat, lon):
    url = f'https://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={API_KEY}&units=metric'
    return requests.get(url).json()

@app.route('/', methods=['GET', 'POST'])
def index():
    weather_data = None

    if request.method == 'POST':
        if 'city' in request.form:
            city = request.form['city']
            response = get_weather_by_city(city)
        else:
            lat = request.form['lat']
            lon = request.form['lon']
            response = get_weather_by_coordinates(lat, lon)

        if response.get('cod') == 200:
            weather_data = {
                'city': response['name'],
                'temperature': response['main']['temp'],
                'feels_like': response['main']['feels_like'],
                'description': response['weather'][0]['description'].title(),
                'icon': response['weather'][0]['icon'],
                'humidity': response['main']['humidity'],
                'wind': response['wind']['speed'],
                'pressure': response['main']['pressure'],
                'visibility': response.get('visibility', 0) / 1000,  # in km
                'sunrise': datetime.fromtimestamp(response['sys']['sunrise']).strftime('%I:%M %p'),
                'sunset': datetime.fromtimestamp(response['sys']['sunset']).strftime('%I:%M %p')
            }
        else:
            weather_data = {'error': 'City not found'}

    return render_template('index.html', weather=weather_data)

if __name__ == '__main__':
    app.run(debug=True)
